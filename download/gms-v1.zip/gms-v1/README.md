# GMS v1 — Gym Management System (release snapshot)

Full v1 snapshot of the modular-monolith Gym Management System: ASP.NET Core 8 API + Next.js 16 RTL admin app, packaged with the complete documentation set any agent (or developer) needs to continue updating the project.

## What shipped in v1 (roadmap 100% — all phases complete)

- **Identity** — JWT auth (roles: admin / reception / buffet / coach, `branchId` claims), PBKDF2 hashing
- **Members / Branches / Catalog** — member files, branch chain, global packages + per-branch grants, buffet products with per-branch prices
- **Sales** — package selling (cash XOR wallet), freeze/unfreeze with expiry shift, pro-rata refunds, universal receipts
- **Attendance** — card-swipe check-in, atomic session consumption, live presence board
- **Wallet** — top-ups, ledger with `BalanceAfter` invariant, account-on-demand
- **Coaching** — coach↔member assignments, training plans (auto-archive), session records
- **Buffet POS** — counter orders, snapshot pricing, wallet/cash settlement with compensation
- **Frontend completion** — role-aware dashboard, reports, member file 360°
- **Hardening** — EF Core migrations (with legacy-DB baseline stamping), rate limiting, audit log, core-invariant test suite, deployment guide

## Package layout

```
gms-v1/
├── backend/    ASP.NET Core 8 solution — Gms.sln (9 modules + *.Public contracts + Api host + tests)
├── frontend/   Next.js 16 App Router + Tailwind + shadcn/ui — RTL fa/en admin app (single-route shell)
├── docs/       Authoritative project docs + phase verification screenshots
├── AGENTS.md   Quick pointer card (original, unchanged)
├── worklog.md  Append-only work history of every phase
└── README.md   This file
```

## Path mapping vs. the original sandbox

The original sandbox had the frontend at the repo root and docs under `download/`. Inside this zip:

| Original path | In this zip |
|---|---|
| repo root (`src/`, `package.json`, `next.config.ts`, …) | `frontend/` |
| `download/gms-*.md` | `docs/` |
| `download/gms-phase*.png` | `docs/screenshots/` |
| `worklog.md`, `AGENTS.md` | zip root (unchanged) |

Older docs reference the original paths (e.g. `download/gms-implementation-plan.md`); read them as `docs/<name>`.

## Docs index — read in this order

1. **`docs/gms-agents-guide.md`** — working protocol: 7-step per-phase workflow, 15 engineering rules, worklog template. **Start here.**
2. **`docs/gms-implementation-plan.md`** (v1.1) — architecture authority: 9 modules, locked product decisions (fa/en bilingual, Toman `long`, no PWA, no inventory, no commissions, …)
3. **`docs/gms-progress.md`** — full roadmap checklist; current state: **100%, all phases ✅** (with per-phase verification notes)
4. **`docs/gms-deployment.md`** — config checklist, migration/baseline behavior, WAL backups, systemd + reverse proxy, smoke checks, rollback
5. **`worklog.md`** — what every previous agent did, phase by phase (append-only)

## Running locally

**Backend** (requires .NET 8 SDK):

```bash
cd backend && dotnet restore && dotnet run --project src/Api/Gms.Api
# Swagger: http://localhost:5000/swagger  ·  seeded login: admin / Admin@123
dotnet test    # core-invariant suite: wallet ledger chain, atomic session consumption, refund math, hasher
```

**Frontend** (bun or Node ≥ 20):

```bash
cd frontend && bun install && bun run dev    # http://localhost:3000
```

- By default the UI runs in **demo-adapter mode**: identical API contracts, local persistence, seeded demo data — no backend needed.
- To bind to the real API: `NEXT_PUBLIC_GMS_API_BASE=http://localhost:5000/api/v1 bun run dev` (see `frontend/.env.example`).

## Rules for future agents (summary — full list in docs/gms-agents-guide.md)

1. Cross-module access **only** via `*.Public` contracts; never FK/JOIN across modules — store ids.
2. One DbContext + one SQLite file per module; WAL enabled at startup; UTC in storage, Jalali at display only.
3. Money = integer Toman (`long`) — never float/double. Errors = ProblemDetails + machine-readable `errorCode`; routes under `/api/v1`.
4. Frontend: single visible route `/`, RTL-first fa with en toggle, shadcn/ui, demo adapter kept contract-exact with the API.
5. After **any** change: update `docs/gms-progress.md` + append `worklog.md` (template in the guide). Never regress locked decisions v1.1.
